﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace Pokemon_Trainer
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            string input = Console.ReadLine();
            var trainers = new List<Trainer>();
            while (input != "Tournament")
            {
                var tokens = input.Split(' ', StringSplitOptions.RemoveEmptyEntries);
                var trainerName = tokens[0];
                var pokemonName = tokens[1];
                var pokemonElement = tokens[2];
                var pokemonHealth = int.Parse(tokens[3]);
                var trainer = trainers.FirstOrDefault(x => x.Name == trainerName); //check in List<Trainer> if trainerName exist !!!

                if (trainer != null) // if exist only add the Pokemon
                {
                    trainer.Pokemons.Add(new Pokemon(pokemonName, pokemonElement, pokemonHealth));
                }
                else // if not exist add new Trainer + the Pokemon
                {
                    var newTrainer = new Trainer(trainerName);
                    newTrainer.Pokemons.Add(new Pokemon(pokemonName, pokemonElement, pokemonHealth));
                    trainers.Add(newTrainer);
                }
                //trainers.Add(trainer);

                input = Console.ReadLine();
            }

            input = Console.ReadLine();

            while (input != "End")
            {
                for (int i = 0; i < trainers.Count; i++)
                {
                    if (trainers[i].Pokemons.All(y => y.Element != input))
                    {
                        foreach (var trainer in trainers[i].Pokemons)
                        {
                            trainer.ReduceHealth();
                        }
                    }
                    else
                    {
                        trainers[i].NumberOfBadges++;
                    }
                }
                input = Console.ReadLine();
            }

            foreach (var trainer in trainers)
            {
                trainer.Pokemons.RemoveAll(x => x.Health <= 0);
            }

            trainers.OrderByDescending(x => x.NumberOfBadges)
                .ToList()
                .ForEach(x => Console.WriteLine($"{x.Name} {x.NumberOfBadges} {x.Pokemons.Count}"));
        }
    }
}
